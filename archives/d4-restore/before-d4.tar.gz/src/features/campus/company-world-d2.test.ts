/// <reference types="node" />
import { readFileSync, writeFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { Mesh, PerspectiveCamera, Raycaster, Scene, Vector3 } from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import {
    companyWorldBundle,
    detailedWorldBundle,
    selectAsset,
} from './asset-bundle';
import type { AssetBundle } from './asset-bundle';
import {
    annotationPosition,
    disposeCampus,
    prepareCampus,
    resolveCampus,
} from './asset';
import { CampusTheme, validateThemeManifest } from './campus-theme';
import { applyRevealLayers, validateRevealLayers } from './reveal-layers';
import { cameraPose, panelInsets } from './camera-framing';
import { architectureFogRange } from './fog-safety';

async function load(bundle: AssetBundle) {
    const file = readFileSync(
        `public/assets/${bundle.manifest.assetId}/${bundle.manifest.assetVersion}/asset.glb`,
    );
    const bytes = new ArrayBuffer(file.byteLength);
    new Uint8Array(bytes).set(file);
    const campus = resolveCampus(
        (await new GLTFLoader().parseAsync(bytes, '')).scene,
        bundle,
    );
    prepareCampus(campus);
    return campus;
}

describe('Company World D.2', () => {
    it('selecciona D.2 solo explícitamente y conserva reversión C.1/campus', () => {
        expect(selectAsset('?world=company-world&v=0.2.0', true)).toBe(
            detailedWorldBundle,
        );
        expect(selectAsset('?world=company-world&v=0.1.0', true)).toBe(
            companyWorldBundle,
        );
        expect(selectAsset('?world=company-world', true)).toBe(
            companyWorldBundle,
        );
        expect(
            selectAsset('?world=company-world&v=0.2.0', false).manifest.assetId,
        ).toBe('arxnet.scene.campus-pilot');
        expect(() => selectAsset('?world=company-world&v=0.3.0', true)).toThrow(
            'Unsupported company world version',
        );
    });
    it('preserva 199 identidades, jerarquías y metadata; acepta 21 materiales y nueve anclas', async () => {
        const campus = await load(detailedWorldBundle);
        expect(campus.nodes.size).toBe(246);
        for (const entry of companyWorldBundle.manifest.nodes)
            expect(
                detailedWorldBundle.manifest.nodes.find(
                    (node) => node.id === entry.id,
                ),
            ).toEqual(entry);
        for (const key of [
            'interactions',
            'revealLayers',
            'overviewFramingNodeIds',
            'visibilityStates',
        ] as const)
            expect(detailedWorldBundle.manifest[key]).toEqual(
                companyWorldBundle.manifest[key],
            );
        expect(() => validateThemeManifest(detailedWorldBundle)).not.toThrow();
        expect(() => validateRevealLayers(campus)).not.toThrow();
        for (const ids of Object.values(
            detailedWorldBundle.manifest.zoneAnchors!,
        ))
            for (const id of ids) {
                const node = campus.nodes.get(id)!;
                expect(node.userData.arxnet_role).toBe('label');
                expect(
                    annotationPosition(node).toArray().every(Number.isFinite),
                ).toBe(true);
                expect(
                    annotationPosition(node).equals(
                        node.getWorldPosition(new Vector3()),
                    ),
                ).toBe(true);
            }
        disposeCampus(campus);
    });
    it('conserva los encuadres y límites C.1 en ambos FOV, escritorio y móvil', async () => {
        const d2 = await load(detailedWorldBundle),
            c1 = await load(companyWorldBundle);
        expect(d2.bounds.equals(c1.bounds)).toBe(true);
        for (const fov of [20, 15])
            for (const size of [
                { width: 1440, height: 900 },
                { width: 1920, height: 1080 },
                { width: 390, height: 844 },
            ]) {
                const camera = new PerspectiveCamera(
                    fov,
                    size.width / size.height,
                    0.5,
                    10000,
                );
                for (const selected of [
                    null,
                    ...d2.departments.map((entry) => entry.departmentId),
                ]) {
                    const insets = panelInsets(size, selected !== null, {
                        top: 64,
                        left: size.width < 760 ? 0 : 70,
                        bottom: 90,
                        right: 0,
                    });
                    const a = cameraPose(
                            d2,
                            selected,
                            camera,
                            camera.aspect,
                            size,
                            insets,
                        ),
                        b = cameraPose(
                            c1,
                            selected,
                            camera,
                            camera.aspect,
                            size,
                            insets,
                        );
                    expect(a.position.distanceTo(b.position)).toBeLessThan(
                        0.0001,
                    );
                    expect(a.target.distanceTo(b.target)).toBeLessThan(0.0001);
                }
            }
        disposeCampus(d2);
        disposeCampus(c1);
    });
    it('mantiene selección por proxies aunque exista mobiliario y restaura luminarias con cubiertas', async () => {
        const campus = await load(detailedWorldBundle);
        const transforms = [...campus.nodes.values()].map((node) =>
            node.matrixWorld.toArray(),
        );
        for (const department of campus.departments) {
            const center = department.bounds.getCenter(new Vector3());
            const ray = new Raycaster(
                center.clone().add(new Vector3(0, 100, 0)),
                new Vector3(0, -1, 0),
            );
            const hits = ray.intersectObject(campus.scene, true);
            expect(hits.length).toBeGreaterThan(0);
            expect(
                hits.every((hit) => hit.object.userData.arxnet_role === 'hit'),
            ).toBe(true);
        }
        for (const quality of ['high', 'balanced', 'low'] as const) {
            for (const selected of ['shared.procurement', 'shared.warehouse']) {
                applyRevealLayers(campus, selected, true, quality);
                const owner = selected.replace('shared.', '');
                expect(campus.nodes.get(`${owner}.roof-fixtures`)!.parent).toBe(
                    campus.nodes.get(`${owner}.roof`),
                );
                expect(campus.nodes.get(`${owner}.roof`)!.visible).toBe(false);
                expect(campus.nodes.get(`${owner}.interior`)!.visible).toBe(
                    true,
                );
                applyRevealLayers(campus, selected, false, quality);
                expect(campus.nodes.get(`${owner}.roof`)!.visible).toBe(true);
                applyRevealLayers(campus, null, false, quality);
                expect(campus.nodes.get(`${owner}.facade-front`)!.visible).toBe(
                    true,
                );
            }
        }
        campus.scene.updateMatrixWorld(true);
        expect(
            [...campus.nodes.values()].map((node) =>
                node.matrixWorld.toArray(),
            ),
        ).toEqual(transforms);
        disposeCampus(campus);
    });
    it('conserva albedos arquitectónicos y monta cuatro luces reales sin sombras ni recompilación por tema', async () => {
        const campus = await load(detailedWorldBundle);
        const rig = new CampusTheme(
            campus,
            new Scene(),
            { toneMappingExposure: 1 },
            'dark',
        );
        expect(rig.materials.size).toBe(21);
        expect(rig.locals).toHaveLength(4);
        const architecture = [...rig.materials]
            .filter(
                ([name]) => !['mat_ad_ground', 'mat_ad_context'].includes(name),
            )
            .flatMap(([, values]) => values);
        const initial = architecture.map((material) => ({
            uuid: material.uuid,
            version: material.version,
            color: material.color.toArray(),
        }));
        rig.locals.forEach((light, i) => {
            const spec = detailedWorldBundle.themes.localLights[i];
            expect(light.parent).toBe(campus.nodes.get(spec.parentNodeId));
            expect(light.position.toArray()).toEqual(spec.position);
            expect(light.castShadow).toBe(false);
            expect(light.distance).toBeLessThanOrEqual(10);
        });
        rig.applyTheme('light', false);
        rig.step(0.32);
        rig.locals.forEach((light, i) =>
            expect(light.intensity).toBeCloseTo(
                detailedWorldBundle.themes.localLights[i].intensity * 0.35,
            ),
        );
        expect(
            architecture.map((material) => ({
                uuid: material.uuid,
                version: material.version,
                color: material.color.toArray(),
            })),
        ).toEqual(initial);
        rig.applyTheme('dark', true);
        expect(rig.locals[0].intensity).toBe(71.6);
        expect(rig.materials.get('mat_ad_fixture')![0].emissiveIntensity).toBe(
            1.6,
        );
        rig.dispose();
        expect(rig.locals.every((light) => light.parent === null)).toBe(true);
        disposeCampus(campus);
    });
    it('demuestra el problema de niebla móvil y conserva el intervalo sin tocar cámaras ni el perfil', async () => {
        const campus = await load(detailedWorldBundle);
        for (const theme of ['dark', 'light'] as const) {
            const base = detailedWorldBundle.themes.themes[theme].fog;
            const mobile = { width: 390, height: 844 };
            const camera = new PerspectiveCamera(
                15,
                mobile.width / mobile.height,
                0.5,
                10000,
            );
            const pose = cameraPose(
                campus,
                null,
                camera,
                camera.aspect,
                mobile,
            );
            camera.position.copy(pose.position);
            camera.lookAt(pose.target);
            camera.updateMatrixWorld(true);
            const direction = camera.getWorldDirection(new Vector3());
            const depths = campus.overviewPoints.map((point) =>
                point.clone().sub(camera.position).dot(direction),
            );
            expect(Math.min(...depths)).toBeGreaterThan(base.far);
            const safe = architectureFogRange(
                campus.overviewPoints,
                camera,
                base.near,
                base.far,
            );
            expect(safe.near).toBeGreaterThan(Math.max(...depths));
            expect(safe.far - safe.near).toBeCloseTo(base.far - base.near);
            expect(camera.position.equals(pose.position)).toBe(true);
            const desktop = new PerspectiveCamera(20, 1440 / 900, 0.5, 10000);
            const overview = cameraPose(campus, null, desktop, desktop.aspect, {
                width: 1440,
                height: 900,
            });
            desktop.position.copy(overview.position);
            desktop.lookAt(overview.target);
            desktop.updateMatrixWorld(true);
            expect(
                architectureFogRange(
                    campus.overviewPoints,
                    desktop,
                    base.near,
                    base.far,
                ).offset,
            ).toBe(0);
        }
        disposeCampus(campus);
    });
    it('registra primitivas/triángulos estáticos de ambos candidatos sin presentarlos como draw calls medidos', async () => {
        const reports: object[] = [];
        for (const bundle of [companyWorldBundle, detailedWorldBundle]) {
            const campus = await load(bundle);
            for (const quality of ['high', 'balanced', 'low'] as const)
                for (const [view, selected, open] of [
                    ['overview', null, false],
                    ['procurement-closed', 'shared.procurement', false],
                    ['procurement-open', 'shared.procurement', true],
                    ['warehouse-closed', 'shared.warehouse', false],
                    ['warehouse-open', 'shared.warehouse', true],
                ] as const) {
                    applyRevealLayers(campus, selected, open, quality);
                    let primitives = 0,
                        triangles = 0;
                    campus.scene.traverseVisible((node) => {
                        if (
                            !(node instanceof Mesh) ||
                            node.userData.arxnet_role !== 'visual'
                        )
                            return;
                        primitives++;
                        triangles +=
                            (node.geometry.index?.count ??
                                node.geometry.attributes.position.count) / 3;
                    });
                    reports.push({
                        version: bundle.manifest.assetVersion,
                        quality,
                        view,
                        primitives,
                        triangles,
                    });
                }
            disposeCampus(campus);
        }
        if (process.env.D2_WRITE_COMPARISON === '1')
            writeFileSync(
                'docs/campus/company-world-d2-static.json',
                JSON.stringify(
                    {
                        kind: 'Visible geometry statistics; not GPU measurements',
                        results: reports,
                    },
                    null,
                    2,
                ) + '\n',
            );
        expect(reports).toHaveLength(30);
    });
});
