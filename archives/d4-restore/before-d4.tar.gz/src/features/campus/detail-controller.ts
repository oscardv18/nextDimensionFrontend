import { Box3, Mesh, Vector3 } from 'three';
import type { Object3D } from 'three';
import type { Campus } from './asset';
import type { QualityName } from './graphics-quality';

export type DetailNavigation = {
    selected: string | null;
    mode: 'overview' | 'focused' | 'manual' | 'transition';
};
export const detailThresholds = {
    balanced: { enter: 90, exit: 110 },
    low: { enter: 45, exit: 65 },
    sampleIntervalMs: 100,
    movementThresholdMeters: 0.5,
    focusedManualExitRatio: 1.25,
};

// El exportador agrupa por material: conservar por defecto las piezas mixtas evita muebles incompletos.
// Solo estas categorías comprobadas contienen objetos secundarios independientes, sin estructura.
export function detailPriority(node: Object3D, departmental: boolean) {
    const category = String(node.userData.arxnet_node_id).split('.').at(-1);
    return departmental && !['screens', 'plants'].includes(category ?? '')
        ? 'essential'
        : 'secondary';
}

type Entry = {
    group: Object3D;
    owner: string | null;
    reference: Vector3 | Box3;
    secondary: Object3D[];
    wholeGroup: boolean;
    near: boolean;
    visible: boolean;
    focusDistance: number;
};

/** Solo modifica visibilidad de los grupos declarados; no controla cámara, selección ni materiales. */
export class DetailController {
    private entries: Entry[];
    private originals = new Map<
        Object3D,
        { visible: boolean; castShadow: boolean }
    >();
    private lastTime = -Infinity;
    private lastPosition = new Vector3(Infinity, Infinity, Infinity);
    private lastState = '';
    changes = 0;

    constructor(campus: Campus, privateQuality: QualityName) {
        this.quality = privateQuality;
        this.entries = campus.detailGroups.map((group) => {
            const department = campus.departments.find(
                (entry) => entry.hit.parent === group.parent,
            );
            const children = group.children.filter(
                (node) => node instanceof Mesh,
            );
            const secondary = children.filter(
                (node) => detailPriority(node, !!department) === 'secondary',
            );
            const wholeGroup = !department;
            for (const node of [group, ...children])
                this.originals.set(node, {
                    visible: node.visible,
                    castShadow: node.castShadow,
                });
            return {
                group,
                owner: department?.departmentId ?? null,
                reference: department
                    ? department.focus.getWorldPosition(new Vector3())
                    : new Box3().setFromObject(group),
                secondary,
                wholeGroup,
                near: false,
                visible: true,
                focusDistance: 0,
            };
        });
    }
    private quality: QualityName;

    update(position: Vector3, navigation: DetailNavigation, now: number) {
        const key = `${navigation.mode}:${navigation.selected}`;
        const stateChanged = key !== this.lastState;
        if (
            !stateChanged &&
            (now - this.lastTime < detailThresholds.sampleIntervalMs ||
                position.distanceToSquared(this.lastPosition) <
                    detailThresholds.movementThresholdMeters ** 2)
        )
            return false;
        this.lastTime = now;
        this.lastState = key;
        this.lastPosition.copy(position);
        let changed = false;
        for (const entry of this.entries) {
            const distance =
                entry.reference instanceof Box3
                    ? entry.reference.distanceToPoint(position)
                    : entry.reference.distanceTo(position);
            const thresholds =
                this.quality === 'low'
                    ? detailThresholds.low
                    : detailThresholds.balanced;
            const ownFocus =
                !!entry.owner &&
                entry.owner === navigation.selected &&
                ['focused', 'transition'].includes(navigation.mode);
            if (ownFocus && navigation.mode === 'focused')
                entry.focusDistance = distance;
            const exit =
                navigation.mode === 'manual' &&
                entry.owner === navigation.selected
                    ? Math.max(
                          thresholds.exit,
                          entry.focusDistance *
                              detailThresholds.focusedManualExitRatio,
                      )
                    : thresholds.exit;
            entry.near =
                ownFocus || distance <= (entry.near ? exit : thresholds.enter);
            let visible =
                this.quality === 'high' ||
                ownFocus ||
                (navigation.mode !== 'overview' && entry.near);
            // Durante un vuelo conservamos lo visible y precargamos el foco nuevo; no retirar piezas en tránsito.
            if (navigation.mode === 'transition' && entry.visible)
                visible = true;
            if (visible === entry.visible) continue;
            entry.visible = visible;
            changed = true;
            this.changes++;
            const controlled = entry.wholeGroup
                ? [entry.group]
                : entry.secondary;
            for (const node of controlled)
                node.visible = visible && this.originals.get(node)!.visible;
        }
        return changed;
    }
    snapshot() {
        return {
            quality: this.quality,
            changes: this.changes,
            groups: this.entries.map((entry) => ({
                id: entry.group.userData.arxnet_node_id,
                owner: entry.owner,
                secondaryVisible: entry.visible,
                wholeGroup: entry.wholeGroup,
                preservedMeshes: entry.group.children.filter(
                    (node) => !entry.secondary.includes(node),
                ).length,
            })),
        };
    }
    dispose() {
        this.originals.forEach((original, node) =>
            Object.assign(node, original),
        );
    }
}
