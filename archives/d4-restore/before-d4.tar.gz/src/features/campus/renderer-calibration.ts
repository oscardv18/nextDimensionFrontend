import {
    BackSide,
    BoxGeometry,
    Mesh,
    MeshBasicMaterial,
    PlaneGeometry,
    Scene,
} from 'three';
import type { MeshStandardMaterial, Texture } from 'three';
import type { CampusTheme } from './campus-theme';

export type GlassEnvironment = 'reference' | 'absolute' | 'relative';
export type LightingExperiment =
    'reference' | 'ambient-half' | 'environment-half' | 'key-half' | 'fill-off';
export type CalibrationOptions = {
    enabled: boolean;
    glass: GlassEnvironment;
    environment: 'room' | 'architecture';
    lighting: LightingExperiment;
};

/** La URL nunca modifica la configuración estable de producción. */
export function calibrationOptions(
    search: string,
    development: boolean,
): CalibrationOptions {
    const params = new URLSearchParams(search);
    const enabled = development && params.get('calibration') === 'on';
    const glass = params.get('glassEnvironment');
    const lighting = params.get('lighting');
    return {
        enabled,
        glass:
            enabled && (glass === 'absolute' || glass === 'relative')
                ? glass
                : 'reference',
        environment:
            enabled && params.get('reflectionEnvironment') === 'architecture'
                ? 'architecture'
                : 'room',
        lighting:
            enabled &&
            (lighting === 'ambient-half' ||
                lighting === 'environment-half' ||
                lighting === 'key-half' ||
                lighting === 'fill-off')
                ? lighting
                : 'reference',
    };
}

export const rendererCalibration = calibrationOptions(
    typeof location === 'undefined' ? '' : location.search,
    import.meta.env.DEV,
);

/** Entorno de prueba procedural: cielo amplio, horizonte cálido y paneles laterales.
 * No representa reflejos locales del campus; no modifica geometría del activo.
 */
export function architecturalReflectionScene() {
    const scene = new Scene();
    const shell = new Mesh(
        new BoxGeometry(40, 30, 40),
        new MeshBasicMaterial({ color: '#303643', side: BackSide }),
    );
    scene.add(shell);
    const panels = [
        {
            size: [22, 18],
            position: [0, 14, 0],
            color: '#b4c5e5',
            intensity: 2.5,
        },
        {
            size: [28, 3],
            position: [0, 0, -18],
            color: '#ffd7aa',
            intensity: 1.2,
        },
        {
            size: [5, 14],
            position: [-18, 3, 0],
            color: '#b0bdd4',
            intensity: 1.4,
        },
        {
            size: [5, 10],
            position: [18, 2, 0],
            color: '#e3d5c1',
            intensity: 0.7,
        },
    ];
    for (const panel of panels) {
        const material = new MeshBasicMaterial({ color: panel.color });
        material.color.multiplyScalar(panel.intensity);
        const mesh = new Mesh(new PlaneGeometry(...panel.size), material);
        mesh.position.set(...(panel.position as [number, number, number]));
        mesh.lookAt(0, 0, 0);
        scene.add(mesh);
    }
    return {
        scene,
        dispose: () =>
            scene.traverse((node) => {
                if (node instanceof Mesh) {
                    node.geometry.dispose();
                    (node.material as MeshBasicMaterial).dispose();
                }
            }),
    };
}

export class RendererCalibration {
    private options: CalibrationOptions;
    private materials: {
        material: MeshStandardMaterial;
        envMap: Texture | null;
        intensity: number;
    }[] = [];
    constructor(options: CalibrationOptions) {
        this.options = options;
    }
    mount(rig: CampusTheme, environment: Texture) {
        if (!this.options.enabled || this.options.glass === 'reference') return;
        for (const material of rig.materials.get('mat_glass_clear') ?? []) {
            this.materials.push({
                material,
                envMap: material.envMap,
                intensity: material.envMapIntensity,
            });
            material.envMap = environment;
        }
        this.syncGlass(rig);
    }
    /** Se ejecuta después de escribir los valores originales: no acumula multiplicadores. */
    apply(rig: CampusTheme, scene: Scene) {
        if (!this.options.enabled) return;
        switch (this.options.lighting) {
            case 'ambient-half':
                rig.hemisphere.intensity *= 0.5;
                break;
            case 'environment-half':
                scene.environmentIntensity *= 0.5;
                break;
            case 'key-half':
                rig.key.intensity *= 0.5;
                break;
            case 'fill-off':
                rig.fill.intensity = 0;
                break;
        }
        this.syncGlass(rig);
    }
    private syncGlass(rig: CampusTheme) {
        for (const { material } of this.materials) {
            // CampusTheme mantiene el valor declarativo del perfil por separado del uniform efectivo.
            const declared = rig.getMaterialEnvironmentIntensity(material.name);
            if (declared !== undefined)
                material.envMapIntensity =
                    declared *
                    (this.options.glass === 'relative'
                        ? rig.environmentIntensity
                        : 1);
        }
    }
    dispose() {
        for (const { material, envMap, intensity } of this.materials) {
            material.envMap = envMap;
            material.envMapIntensity = intensity;
        }
        this.materials = [];
    }
}
