/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { Scene, Texture } from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { disposeCampus, prepareCampus, resolveCampus } from './asset';
import { CampusTheme, validateThemeManifest } from './campus-theme';
import { activeAsset } from './asset-bundle';
import { graphicsOptions } from './graphics-quality';
import {
    architecturalReflectionScene,
    calibrationOptions,
    RendererCalibration,
} from './renderer-calibration';

async function fixture(query: string) {
    const file = readFileSync(
        'public/assets/arxnet.scene.campus-pilot/0.4.0/asset.glb',
    );
    const bytes = new ArrayBuffer(file.byteLength);
    new Uint8Array(bytes).set(file);
    const campus = resolveCampus(
        (await new GLTFLoader().parseAsync(bytes, '')).scene,
    );
    prepareCampus(campus);
    const scene = new Scene();
    const calibration = new RendererCalibration(
        calibrationOptions(query, true),
    );
    const rig = new CampusTheme(
        campus,
        scene,
        { toneMappingExposure: 1 },
        'dark',
        graphicsOptions('', false),
        (rig, scene) => calibration.apply(rig, scene),
    );
    const environment = new Texture();
    scene.environment = environment;
    calibration.mount(rig, environment);
    return {
        scene,
        rig,
        calibration,
        environment,
        dispose: () => {
            calibration.dispose();
            rig.dispose();
            disposeCampus(campus);
            environment.dispose();
        },
    };
}

describe('calibración reversible del renderer 0.4.0', () => {
    it('no acepta silenciosamente el esquema candidato ni materiales ausentes de 0.4.0', () => {
        const candidate = structuredClone(activeAsset);
        candidate.themes.profileVersion = '1.1.0';
        expect(() => validateThemeManifest(candidate)).toThrow(
            'Theme identity mismatch',
        );
        candidate.themes.profileVersion = activeAsset.themes.profileVersion;
        Object.assign(candidate.themes.themes.dark.materials, {
            mat_glass_facade: { opacity: 0.3 },
        });
        expect(() => validateThemeManifest(candidate)).toThrow(
            'Unsupported theme material',
        );
    });
    it('ignora todos los parámetros en producción y exige opt-in en desarrollo', () => {
        const query =
            '?calibration=on&glassEnvironment=absolute&reflectionEnvironment=architecture&lighting=fill-off';
        expect(calibrationOptions(query, false)).toEqual(
            calibrationOptions('', true),
        );
        expect(
            calibrationOptions('?glassEnvironment=relative', true).glass,
        ).toBe('reference');
        expect(
            calibrationOptions(
                '?calibration=on&glassEnvironment=unknown&lighting=unknown',
                true,
            ).lighting,
        ).toBe('reference');
    });
    it('preserva la referencia sin mapa explícito y sin cambiar luces', async () => {
        const f = await fixture('?calibration=on');
        expect(f.rig.materials.get('mat_glass_clear')![0].envMap).toBeNull();
        expect(f.scene.environmentIntensity).toBe(0.2);
        expect(f.rig.hemisphere.intensity).toBe(0.9);
        expect(f.rig.fill.intensity).toBe(0.4);
        f.dispose();
    });
    for (const mode of ['absolute', 'relative'])
        it(`aplica ${mode} con el mismo PMREM, preserva identidad y restaura mapa`, async () => {
            const f = await fixture(`?calibration=on&glassEnvironment=${mode}`);
            const glass = f.rig.materials.get('mat_glass_clear')![0];
            const identity = {
                uuid: glass.uuid,
                version: glass.version,
                map: glass.map,
            };
            expect(glass.envMap).toBe(f.environment);
            expect(glass.envMapIntensity).toBeCloseTo(
                mode === 'absolute' ? 1 : 0.2,
            );
            f.rig.applyTheme('light', false);
            f.rig.step(0.16);
            expect(glass.envMapIntensity).toBeCloseTo(
                mode === 'absolute' ? 1.2 : 1.2 * 0.45,
            );
            f.rig.step(0.16);
            expect(glass.envMapIntensity).toBeCloseTo(
                mode === 'absolute' ? 1.4 : 0.98,
            );
            f.rig.applyTheme('dark', true);
            expect({
                uuid: glass.uuid,
                version: glass.version,
                map: glass.map,
            }).toEqual(identity);
            expect(glass.opacity).toBe(0.14);
            expect(glass.transparent).toBe(true);
            f.calibration.dispose();
            expect(glass.envMap).toBeNull();
            expect(glass.envMapIntensity).toBe(1);
            f.dispose();
        });
    it('no acumula multiplicadores, conserva transiciones rápidas y no mezcla entorno relativo', async () => {
        const f = await fixture(
            '?calibration=on&glassEnvironment=relative&lighting=environment-half',
        );
        expect(
            f.rig.materials.get('mat_glass_clear')![0].envMapIntensity,
        ).toBeCloseTo(0.1);
        f.rig.applyTheme('light', false);
        f.rig.step(0.16);
        f.rig.applyTheme('dark', false);
        f.rig.step(0);
        f.rig.step(0.32);
        expect(f.scene.environmentIntensity).toBeCloseTo(0.1);
        expect(
            f.rig.materials.get('mat_glass_clear')![0].envMapIntensity,
        ).toBeCloseTo(0.1);
        f.rig.applyTheme('light', true);
        expect(f.scene.environmentIntensity).toBeCloseTo(0.35);
        expect(
            f.rig.materials.get('mat_glass_clear')![0].envMapIntensity,
        ).toBeCloseTo(0.49);
        f.dispose();
    });
    it('aísla hemisferio, principal y relleno en ambos temas sin afectar otras luces', async () => {
        for (const lighting of ['ambient-half', 'key-half', 'fill-off']) {
            const f = await fixture(`?calibration=on&lighting=${lighting}`);
            for (const theme of ['dark', 'light'] as const) {
                f.rig.applyTheme(theme, true);
                const dark = theme === 'dark';
                expect(f.rig.hemisphere.intensity).toBe(
                    (dark ? 0.9 : 1.4) *
                        (lighting === 'ambient-half' ? 0.5 : 1),
                );
                expect(f.rig.key.intensity).toBe(
                    (dark ? 0.6 : 3.2) * (lighting === 'key-half' ? 0.5 : 1),
                );
                expect(f.rig.fill.intensity).toBe(
                    lighting === 'fill-off' ? 0 : dark ? 0.4 : 0.5,
                );
                expect(f.rig.locals).toHaveLength(14);
                expect(f.rig.locals[0].intensity).toBe(dark ? 90 : 0);
            }
            f.dispose();
        }
    });
    it('crea un entorno procedural independiente y libera sus recursos', () => {
        const environment = architecturalReflectionScene();
        expect(environment.scene.children).toHaveLength(5);
        expect(() => environment.dispose()).not.toThrow();
    });
});
