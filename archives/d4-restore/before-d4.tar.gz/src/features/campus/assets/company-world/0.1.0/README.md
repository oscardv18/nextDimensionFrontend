# Paquete de transferencia c1: arxnet.scene.company-world 0.1.0 (experimental)

No apto para producción. Documento completo: docs/company-world-handoff-c1.md (repositorio arxnet-3d).

Codex consume: asset.glb, manifest.json, build.json y themes.json, siempre juntos.
De apoyo: camera-candidates.json (D6 abierta), acceptance.json (AC1–AC13) y validation-summary.json.

Verificación: sha256sum -c SHA256SUMS
Reversión: desactivar el indicador del frontend; campus-pilot 0.4.0 no se ha modificado.
