import manifest from './assets/manifest.json';
import build from './assets/build.json';
import themes from './assets/themes.json';
import previousManifest from './assets/0.3.0/manifest.json';
import previousBuild from './assets/0.3.0/build.json';
import previousThemes from './assets/0.3.0/themes.json';
import worldManifest from './assets/company-world/0.1.0/manifest.json';
import worldBuild from './assets/company-world/0.1.0/build.json';
import worldThemes from './assets/company-world/0.1.0/themes.json';
import worldCameras from './assets/company-world/0.1.0/camera-candidates.json';
import detailedManifest from './assets/company-world/0.2.0/manifest.json';
import detailedBuild from './assets/company-world/0.2.0/build.json';
import detailedThemes from './assets/company-world/0.2.0/themes.json';
import detailedCameras from './assets/company-world/0.2.0/camera-candidates.json';

export type ThemePatch = {
    color?: string;
    opacity?: number;
    envMapIntensity?: number;
    emissiveIntensity?: number;
};
export type ThemeProfile = Omit<
    typeof themes,
    'materials' | 'textures' | 'themes' | 'conventions'
> & {
    conventions: Record<string, string>;
    textures: Record<string, unknown>;
    materials: Record<
        string,
        {
            class: string;
            color?: string;
            emissive?: string;
            envMapIntensity?: number;
            themeKeys?: string[];
        }
    >;
    themes: Record<
        'dark' | 'light',
        Omit<typeof themes.themes.dark, 'materials' | 'effects'> & {
            materials: Record<string, ThemePatch>;
            effects: Record<string, unknown>;
        }
    >;
};
export type CampusManifest = {
    assetId: string;
    assetVersion: string;
    contractVersion: string;
    nodes: { id: string; name: string; role: string; parent: string | null }[];
    departmentIds: string[];
    interactions: typeof manifest.interactions;
    environmentNodeIds: string[];
    detailNodeIds?: string[];
    revealLayers?: typeof worldManifest.revealLayers;
    visibilityStates?: typeof worldManifest.visibilityStates;
    defaultHiddenNodeIds?: string[];
    overviewFramingNodeIds?: string[];
    accentMaterials?: string[];
    zoneAnchors?: Record<string, string[]>;
};
export type AssetBundle = {
    manifest: CampusManifest;
    build: {
        assetId: string;
        assetVersion: string;
        metrics: { bytes: number; sha256: string };
    };
    themes: ThemeProfile;
    cameraCandidates?: typeof worldCameras;
};
export const companyWorldBundle: AssetBundle = {
    manifest: worldManifest,
    build: worldBuild,
    themes: worldThemes,
    cameraCandidates: worldCameras,
};
export const detailedWorldBundle: AssetBundle = {
    manifest: detailedManifest,
    build: detailedBuild,
    themes: detailedThemes,
    cameraCandidates: detailedCameras,
};
export const companyWorldBundles: Record<string, AssetBundle> = {
    '0.1.0': companyWorldBundle,
    '0.2.0': detailedWorldBundle,
};

export const assetBundles = {
    '0.4.0': { manifest, build, themes },
    '0.3.0': {
        manifest: previousManifest,
        build: previousBuild,
        themes: previousThemes,
    },
};

/** Reversión coordinada: siempre se elige GLB + manifiesto + build + perfil juntos. */
export function chooseAsset(version = '0.4.0'): AssetBundle {
    if (version !== '0.4.0' && version !== '0.3.0')
        throw new Error(`Unsupported campus version: ${version}`);
    return assetBundles[version];
}
/** El mundo nuevo solo se activa por URL en desarrollo; nunca se persiste. */
export function selectAsset(
    search: string,
    development: boolean,
    stableVersion = '0.4.0',
): AssetBundle {
    const params = new URLSearchParams(development ? search : '');
    if (params.get('world') === 'company-world') {
        const version = params.get('v') ?? '0.1.0';
        const bundle = companyWorldBundles[version];
        if (!bundle)
            throw new Error(`Unsupported company world version: ${version}`);
        return bundle;
    }
    return chooseAsset(params.get('assetVersion') ?? stableVersion);
}
export function worldFov(search: string, bundle: AssetBundle) {
    if (!bundle.cameraCandidates) return 45;
    return new URLSearchParams(search).get('fov') === '15' ? 15 : 20;
}
export const activeAsset = selectAsset(
    typeof location === 'undefined' ? '' : location.search,
    import.meta.env.DEV,
    import.meta.env.VITE_CAMPUS_ASSET_VERSION ?? '0.4.0',
);
