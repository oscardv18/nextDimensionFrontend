/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import {
    Box3,
    Color,
    Mesh,
    MeshStandardMaterial,
    Scene,
    SRGBColorSpace,
} from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { manifest, prepareCampus, resolveCampus, disposeCampus } from './asset';
import {
    CampusTheme,
    themeManifest,
    validateThemeManifest,
} from './campus-theme';
import previous from './assets/0.2.0/manifest.json';
import { navigationLimits } from './manual-navigation';
async function load() {
    const file = readFileSync(
        'public/assets/arxnet.scene.campus-pilot/0.4.0/asset.glb',
    );
    const bytes = new ArrayBuffer(file.byteLength);
    new Uint8Array(bytes).set(file);
    const campus = resolveCampus(
        (await new GLTFLoader().parseAsync(bytes, '')).scene,
    );
    prepareCampus(campus);
    return campus;
}
describe('compatibilidad y temas PBR 0.4.0', () => {
    it('invalida sombras cuando cambia la dirección de la luz, conserva el mapa en reposo y permite calidad baja', async () => {
        const campus = await load();
        const { graphicsOptions } = await import('./graphics-quality');
        const rig = new CampusTheme(
            campus,
            new Scene(),
            { toneMappingExposure: 1 },
            'dark',
            graphicsOptions('?quality=low', true),
        );
        expect(rig.key.shadow.mapSize.x).toBe(512);
        rig.key.shadow.needsUpdate = false;
        expect(rig.step(0.5)).toBe(false);
        expect(rig.key.shadow.needsUpdate).toBe(false);
        rig.applyTheme('light', false);
        rig.step(0.16);
        expect(rig.key.shadow.needsUpdate).toBe(true);
        rig.key.shadow.needsUpdate = false;
        rig.step(0.16);
        expect(rig.key.shadow.needsUpdate).toBe(true);
        rig.key.shadow.needsUpdate = false;
        rig.step(10);
        expect(rig.key.shadow.needsUpdate).toBe(false);
        expect(rig.locals).toHaveLength(14);
        expect(rig.locals.every((light) => !light.castShadow)).toBe(true);
        rig.dispose();
        disposeCampus(campus);
    });
    it('conserva las 94 identidades y seis interacciones; perfil externo compatible', () => {
        expect(manifest.nodes).toHaveLength(139);
        for (const node of previous.nodes)
            expect(manifest.nodes.find((n) => n.id === node.id)).toEqual(node);
        expect(manifest.interactions).toEqual(previous.interactions);
        expect(() => validateThemeManifest()).not.toThrow();
        expect(themeManifest.environmentNodeIds).toEqual(
            manifest.environmentNodeIds,
        );
    });
    it('excluye el suelo de 420 m y conserva los límites de exploración anteriores', async () => {
        const campus = await load();
        const total = new Box3().setFromObject(campus.scene);
        expect(total.max.x - total.min.x).toBeGreaterThan(800);
        expect(campus.bounds.max.x - campus.bounds.min.x).toBeLessThan(110);
        const file = readFileSync(
            'public/assets/arxnet.scene.campus-pilot/0.2.0/asset.glb',
        );
        const bytes = new ArrayBuffer(file.byteLength);
        new Uint8Array(bytes).set(file);
        const old = (await new GLTFLoader().parseAsync(bytes, '')).scene;
        expect(navigationLimits(campus.bounds)).toEqual(
            navigationLimits(new Box3().setFromObject(old)),
        );
        disposeCampus(campus);
    });
    it('cambia uniforms sin crear materiales, luces o modificar programas de material', async () => {
        const campus = await load(),
            scene = new Scene(),
            renderer = { toneMappingExposure: 1 };
        const rig = new CampusTheme(campus, scene, renderer, 'dark');
        const materials = [...rig.materials.values()].flat();
        const invariants = materials.map((m) => ({
            uuid: m.uuid,
            version: m.version,
            map: m.map,
            side: m.side,
            transparent: m.transparent,
        }));
        const count = scene.children.length,
            locals = rig.locals.map((l) => l.uuid);
        for (let i = 0; i < 8; i++) {
            rig.applyTheme('light', true);
            rig.applyTheme('dark', true);
        }
        expect(
            materials.map((m) => ({
                uuid: m.uuid,
                version: m.version,
                map: m.map,
                side: m.side,
                transparent: m.transparent,
            })),
        ).toEqual(invariants);
        expect(scene.children.length).toBe(count);
        expect(rig.locals.map((l) => l.uuid)).toEqual(locals);
        expect(renderer.toneMappingExposure).toBe(1);
        expect(rig.background.getHexString()).toBe('07090d');
        expect(rig.locals).toHaveLength(14);
        rig.dispose();
        disposeCampus(campus);
    });
    it('aplica valores de claro y oscuro del manifiesto, incluida emisión sin factor duplicado', async () => {
        const campus = await load(),
            scene = new Scene(),
            renderer = { toneMappingExposure: 1 };
        const rig = new CampusTheme(campus, scene, renderer, 'dark');
        const warm = rig.materials.get('mat_emissive_warm')![0];
        expect(
            warm.emissive.equals(
                new Color(themeManifest.materials.mat_emissive_warm.emissive),
            ),
        ).toBe(true);
        expect(warm.emissiveIntensity).toBe(2.4);
        rig.applyTheme('light', true);
        expect(rig.locals.every((l) => l.intensity === 0 && l.visible)).toBe(
            true,
        );
        expect(rig.key.intensity).toBe(3.2);
        expect(renderer.toneMappingExposure).toBe(0.9);
        expect(rig.fog.far).toBe(760);
        expect(scene.environmentIntensity).toBe(0.7);
        expect(rig.materials.get('mat_glass_clear')![0].opacity).toBe(0.26);
        expect(warm.emissiveIntensity).toBe(0);
        expect(rig.background.getHexString()).toBe('dfe3ea');
        rig.applyTheme('dark', true);
        expect(rig.locals[0].intensity).toBe(90);
        rig.dispose();
        disposeCampus(campus);
    });
    it('interrumpe una transición desde sus uniforms actuales y respeta movimiento reducido', async () => {
        const campus = await load(),
            scene = new Scene(),
            renderer = { toneMappingExposure: 1 };
        const rig = new CampusTheme(campus, scene, renderer, 'dark');
        rig.applyTheme('light', false);
        expect(rig.step(0.16)).toBe(true);
        expect(rig.key.intensity).toBeCloseTo(1.9);
        const interrupted = rig.key.intensity;
        rig.applyTheme('dark', false);
        rig.step(0);
        expect(rig.key.intensity).toBe(interrupted);
        expect(rig.step(0.32)).toBe(false);
        expect(rig.key.intensity).toBe(0.6);
        rig.applyTheme('light', true);
        expect(rig.step(0)).toBe(false);
        expect(rig.key.intensity).toBe(3.2);
        rig.dispose();
        expect(scene.children).toHaveLength(0);
        expect(rig.locals.every((l) => l.parent === null)).toBe(true);
        disposeCampus(campus);
    });
    it('conserva PBR, mapas sRGB, vidrio de una cara y sombras solo en opacos', async () => {
        const campus = await load();
        let mapped = 0;
        const maps = new Set();
        campus.scene.traverse((node) => {
            if (!(node instanceof Mesh)) return;
            for (const material of Array.isArray(node.material)
                ? node.material
                : [node.material]) {
                expect(material).toBeInstanceOf(MeshStandardMaterial);
                const pbr = material as MeshStandardMaterial;
                if (pbr.map) {
                    mapped++;
                    maps.add(pbr.map);
                    expect(pbr.map.colorSpace).toBe(SRGBColorSpace);
                }
                if (material.transparent) {
                    expect(node.castShadow).toBe(false);
                    expect(material.depthWrite).toBe(false);
                    expect(material.side).toBe(0);
                }
            }
        });
        expect(mapped).toBeGreaterThan(0);
        expect(maps.size).toBe(4);
        expect(
            (campus.nodes.get('site.environment-ground') as Mesh).receiveShadow,
        ).toBe(true);
        expect(
            (campus.nodes.get('site.environment-ground') as Mesh).castShadow,
        ).toBe(false);
        disposeCampus(campus);
    });
});
