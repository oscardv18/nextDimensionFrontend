/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { webcrypto } from 'node:crypto';
import { expect, it, vi } from 'vitest';
import { PerspectiveCamera, Scene, Vector3 } from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { assetBundles, chooseAsset } from './asset-bundle';
import {
    cameraPose,
    disposeCampus,
    prepareCampus,
    resolveCampus,
    verifyAsset,
    setRoofVisibility,
} from './asset';
import { CampusTheme, validateThemeManifest } from './campus-theme';
import { DetailController, detailPriority } from './detail-controller';
import { navigationLimits } from './manual-navigation';

async function load(version: keyof typeof assetBundles = '0.4.0') {
    const file = readFileSync(
        `public/assets/arxnet.scene.campus-pilot/${version}/asset.glb`,
    );
    const bytes = new ArrayBuffer(file.byteLength);
    new Uint8Array(bytes).set(file);
    const campus = resolveCampus(
        (await new GLTFLoader().parseAsync(bytes, '')).scene,
        assetBundles[version],
    );
    prepareCampus(campus);
    return { campus, bytes };
}
it('conserva las 99 identidades y las seis interacciones sin mezclar versiones', async () => {
    const current = assetBundles['0.4.0'],
        previous = assetBundles['0.3.0'];
    expect(current.manifest.nodes).toHaveLength(139);
    for (const old of previous.manifest.nodes)
        expect(current.manifest.nodes.find((n) => n.id === old.id)).toEqual(
            old,
        );
    expect(current.manifest.interactions).toEqual(
        previous.manifest.interactions,
    );
    expect(() =>
        validateThemeManifest({ ...current, themes: previous.themes }),
    ).toThrow('identity');
    expect(() => chooseAsset('0.2.0')).toThrow('Unsupported');
    expect(chooseAsset('0.3.0')).toBe(previous);
});

it('revierte realmente a 0.3.0 con geometría, hash, perfil y consumidor compatibles', async () => {
    vi.stubGlobal('crypto', webcrypto);
    const { campus, bytes } = await load('0.3.0');
    await expect(verifyAsset(bytes, campus.bundle)).resolves.toBeUndefined();
    await expect(verifyAsset(bytes, assetBundles['0.4.0'])).rejects.toThrow(
        'size',
    );
    expect(campus.nodes.size).toBe(99);
    expect(campus.detailGroups).toHaveLength(0);
    const rig = new CampusTheme(
        campus,
        new Scene(),
        { toneMappingExposure: 1 },
        'dark',
    );
    expect(rig.materials.size).toBe(23);
    rig.applyTheme('light', true);
    expect(rig.key.intensity).toBe(3.2);
    const detail = new DetailController(campus, 'low');
    expect(
        detail.update(new Vector3(), { selected: null, mode: 'overview' }, 0),
    ).toBe(false);
    rig.dispose();
    detail.dispose();
    disposeCampus(campus);
    vi.unstubAllGlobals();
});

it('mantiene límites y encuadres de 0.3.0 en los seis departamentos y vista general', async () => {
    const { campus: old } = await load('0.3.0'),
        { campus } = await load();
    expect(navigationLimits(campus.bounds)).toEqual(
        navigationLimits(old.bounds),
    );
    for (const size of [
        { width: 1440, height: 900 },
        { width: 1920, height: 1080 },
        { width: 390, height: 844 },
    ]) {
        const camera = new PerspectiveCamera(
            45,
            size.width / size.height,
            0.1,
            1500,
        );
        for (const id of [null, ...campus.bundle.manifest.departmentIds]) {
            const before = cameraPose(old, id, camera, camera.aspect, size);
            const after = cameraPose(campus, id, camera, camera.aspect, size);
            expect(after.position.distanceTo(before.position)).toBeLessThan(
                0.0001,
            );
            expect(after.target.distanceTo(before.target)).toBeLessThan(0.0001);
        }
    }
    disposeCampus(old);
    disposeCampus(campus);
});

it('Alta conserva todo; los otros perfiles preservan muebles, mercancía, equipos y cubierta', async () => {
    const { campus } = await load();
    for (const quality of ['high', 'balanced', 'low'] as const) {
        const detail = new DetailController(campus, quality);
        detail.update(
            new Vector3(0, 200, 0),
            { selected: null, mode: 'overview' },
            0,
        );
        for (const group of campus.detailGroups) {
            const owner = campus.departments.find(
                (d) => d.hit.parent === group.parent,
            );
            for (const node of group.children) {
                if (owner && detailPriority(node, true) === 'essential')
                    expect(node.visible).toBe(true);
                if (quality === 'high')
                    expect(node.visible && group.visible).toBe(true);
            }
            if (!owner) expect(group.visible).toBe(quality === 'high');
        }
        setRoofVisibility(campus, true);
        detail.update(
            new Vector3(),
            { selected: campus.departments[0].departmentId, mode: 'focused' },
            200,
        );
        expect(campus.roof.visible).toBe(false);
        setRoofVisibility(campus, false);
        detail.dispose();
        expect(
            campus.detailGroups.every(
                (g) => g.visible && g.children.every((n) => n.visible),
            ),
        ).toBe(true);
    }
    disposeCampus(campus);
});

it('usa foco real e histéresis 90/110 m; no alterna en la banda ni evalúa cada frame', async () => {
    const { campus } = await load();
    const department = campus.departments[0],
        focus = department.focus.getWorldPosition(new Vector3());
    const group = campus.detailGroups.find(
        (g) => g.parent === department.hit.parent,
    )!;
    const secondary = group.children.find(
        (n) => detailPriority(n, true) === 'secondary',
    )!;
    const detail = new DetailController(campus, 'balanced');
    const state = { selected: null, mode: 'manual' as const };
    const position = (distance: number) =>
        focus.clone().add(new Vector3(0, distance, 0));
    detail.update(position(111), state, 0);
    expect(secondary.visible).toBe(false);
    detail.update(position(89), state, 200);
    expect(secondary.visible).toBe(true);
    detail.update(position(100), state, 400);
    expect(secondary.visible).toBe(true);
    detail.update(position(112), state, 450);
    expect(secondary.visible).toBe(true);
    detail.update(position(112), state, 600);
    expect(secondary.visible).toBe(false);
    detail.update(position(100), state, 800);
    expect(secondary.visible).toBe(false);
    detail.update(position(89), state, 1000);
    expect(secondary.visible).toBe(true);
    detail.dispose();
    disposeCampus(campus);
});

it('precarga el foco en vuelo, difiere retiradas y restaura detalle al acercarse en Baja', async () => {
    const { campus } = await load();
    const detail = new DetailController(campus, 'low');
    const department = campus.departments[1],
        focus = department.focus.getWorldPosition(new Vector3());
    const group = campus.detailGroups.find(
        (g) => g.parent === department.hit.parent,
    )!;
    const secondary = group.children.find(
        (n) => detailPriority(n, true) === 'secondary',
    )!;
    const far = new Vector3(200, 200, 200);
    detail.update(far, { selected: null, mode: 'overview' }, 0);
    expect(secondary.visible).toBe(false);
    detail.update(
        far,
        { selected: department.departmentId, mode: 'transition' },
        1,
    );
    expect(secondary.visible).toBe(true);
    detail.update(
        far,
        { selected: campus.departments[3].departmentId, mode: 'transition' },
        2,
    );
    expect(secondary.visible).toBe(true);
    detail.update(far, { selected: null, mode: 'overview' }, 3);
    expect(secondary.visible).toBe(false);
    detail.update(
        focus.clone().add(new Vector3(0, 44, 0)),
        { selected: null, mode: 'manual' },
        4,
    );
    expect(secondary.visible).toBe(true);
    detail.dispose();
    disposeCampus(campus);
});

it('conserva detalle al iniciar exploración desde un foco lejano en un viewport estrecho', async () => {
    const { campus } = await load();
    const detail = new DetailController(campus, 'low');
    const department = campus.departments[0],
        focus = department.focus.getWorldPosition(new Vector3());
    const group = campus.detailGroups.find(
        (g) => g.parent === department.hit.parent,
    )!;
    const secondary = group.children.find(
        (n) => detailPriority(n, true) === 'secondary',
    )!;
    const position = (distance: number) =>
        focus.clone().add(new Vector3(0, distance, 0));
    detail.update(
        position(120),
        { selected: department.departmentId, mode: 'focused' },
        0,
    );
    detail.update(
        position(124),
        { selected: department.departmentId, mode: 'manual' },
        200,
    );
    expect(secondary.visible).toBe(true);
    detail.update(
        position(151),
        { selected: department.departmentId, mode: 'manual' },
        400,
    );
    expect(secondary.visible).toBe(false);
    detail.dispose();
    disposeCampus(campus);
});
