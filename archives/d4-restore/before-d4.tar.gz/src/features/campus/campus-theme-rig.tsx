import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import {
    PMREMGenerator,
    PCFShadowMap,
    PCFSoftShadowMap,
    Mesh,
    MeshStandardMaterial,
} from 'three';
import type { Scene, WebGLRenderer } from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { Campus } from './asset';
import { CampusTheme } from './campus-theme';
import type { ThemeName } from './campus-theme';
import { recordCameraDiagnostic } from './camera-diagnostics';
import { architectureFogRange } from './fog-safety';
import { campusGraphics } from './graphics-quality';
import { requestShadowUpdate, cacheShadowMaps } from './shadow-cache';
import {
    architecturalReflectionScene,
    rendererCalibration,
    RendererCalibration,
} from './renderer-calibration';

function mountTheme(
    campus: Campus,
    scene: Scene,
    gl: WebGLRenderer,
    theme: ThemeName,
) {
    const calibration = new RendererCalibration(rendererCalibration);
    const lighting = new CampusTheme(
        campus,
        scene,
        gl,
        theme,
        campusGraphics,
        rendererCalibration.enabled
            ? (rig, scene) => calibration.apply(rig, scene)
            : undefined,
    );
    const generator = new PMREMGenerator(gl),
        architecture =
            rendererCalibration.enabled &&
            rendererCalibration.environment === 'architecture'
                ? architecturalReflectionScene()
                : null,
        room = architecture?.scene ?? new RoomEnvironment();
    let environment;
    try {
        environment = generator.fromScene(room, 0.04);
    } catch (error) {
        lighting.dispose();
        throw error;
    } finally {
        generator.dispose();
        if (architecture) architecture.dispose();
        else (room as RoomEnvironment).dispose();
    }
    const previous = scene.environment;
    const previousShadows = {
        autoUpdate: gl.shadowMap.autoUpdate,
        enabled: gl.shadowMap.enabled,
        type: gl.shadowMap.type,
    };
    const releaseCache = cacheShadowMaps(gl);
    gl.shadowMap.enabled = campusGraphics.shadows;
    gl.shadowMap.type = campusGraphics.softShadows
        ? PCFSoftShadowMap
        : PCFShadowMap;
    gl.shadowMap.needsUpdate = true;
    const changed: { node: Mesh; visible: boolean; castShadow: boolean }[] = [];
    campus.scene.traverse((node) => {
        if (!(node instanceof Mesh)) return;
        const materials = Array.isArray(node.material)
            ? node.material
            : [node.material];
        const vegetation = campus.bundle.manifest.environmentNodeIds.some(
            (id) =>
                id === node.userData.arxnet_node_id &&
                id.startsWith('site.vegetation-'),
        );
        if (
            (!campusGraphics.transparency &&
                materials.some((m) => m.transparent)) ||
            (!campusGraphics.vegetationShadows && vegetation)
        ) {
            changed.push({
                node,
                visible: node.visible,
                castShadow: node.castShadow,
            });
            if (
                !campusGraphics.transparency &&
                materials.some((m) => m.transparent)
            )
                node.visible = false;
            if (vegetation && !campusGraphics.vegetationShadows)
                node.castShadow = false;
        }
    });
    scene.environment = environment.texture;
    calibration.mount(lighting, environment.texture);
    let calibrationRelease = () => {};
    if (import.meta.env.DEV && rendererCalibration.enabled) {
        gl.domElement.dataset.rendererCalibration =
            JSON.stringify(rendererCalibration);
        // Captura del uniform realmente enviado por Three; no solo de la propiedad JS.
        const glass = new Set(lighting.materials.get('mat_glass_clear') ?? []);
        const releases: (() => void)[] = [];
        let lastSample = '';
        campus.scene.traverse((node) => {
            if (!(node instanceof Mesh) || node.userData.arxnet_role === 'hit')
                return;
            const material = (
                Array.isArray(node.material) ? node.material : [node.material]
            ).find(
                (material): material is MeshStandardMaterial =>
                    material instanceof MeshStandardMaterial &&
                    glass.has(material),
            );
            if (!material) return;
            const original = node.onAfterRender;
            node.onAfterRender = function (...args) {
                original.apply(this, args);
                if (gl.domElement.dataset.themeSettled !== 'true') return;
                const sample = `${lighting.environmentIntensity}/${lighting.getMaterialEnvironmentIntensity(material.name)}`;
                if (lastSample === sample) return;
                const properties = gl.properties.get(material) as {
                    currentProgram?: { program: WebGLProgram; id: number };
                };
                const program = properties.currentProgram;
                if (!program) return;
                const context = gl.getContext();
                const uniform = context.getUniformLocation(
                    program.program,
                    'envMapIntensity',
                );
                if (uniform === null) return;
                lastSample = sample;
                gl.domElement.dataset.glassEnvironment = JSON.stringify({
                    mode: rendererCalibration.glass,
                    explicitMap:
                        'envMap' in material && material.envMap !== null,
                    propertyIntensity:
                        'envMapIntensity' in material
                            ? material.envMapIntensity
                            : null,
                    sceneIntensity: scene.environmentIntensity,
                    programId: program?.id,
                    measuredUniformIntensity: context.getUniform(
                        program.program,
                        uniform,
                    ),
                });
            };
            releases.push(() => {
                node.onAfterRender = original;
            });
        });
        // Restaurar los callbacks al desmontar junto con los recursos del experimento.
        calibrationRelease = () => releases.forEach((release) => release());
    }
    return {
        lighting,
        dispose: () => {
            calibrationRelease();
            calibration.dispose();
            lighting.dispose();
            releaseCache();
            Object.assign(gl.shadowMap, previousShadows);
            changed.forEach(({ node, visible, castShadow }) =>
                Object.assign(node, { visible, castShadow }),
            );
            if (scene.environment === environment.texture)
                scene.environment = previous;
            environment.dispose();
        },
    };
}

export function CampusThemeRig({
    campus,
    theme,
    reducedMotion,
}: {
    campus: Campus;
    theme: ThemeName;
    reducedMotion: boolean;
}) {
    const { scene, gl, camera, invalidate } = useThree();
    const rig = useRef<CampusTheme | null>(null);
    const initial = useRef(theme);
    const frames = useRef(0);
    const previousTime = useRef(0);
    useEffect(() => {
        const mounted = mountTheme(campus, scene, gl, initial.current);
        rig.current = mounted.lighting;
        frames.current = 0;
        invalidate();
        return () => {
            mounted.dispose();
            rig.current = null;
        };
    }, [campus, scene, gl, invalidate]);
    useEffect(() => {
        rig.current?.applyTheme(theme, reducedMotion);
        previousTime.current = performance.now();
        invalidate();
    }, [theme, reducedMotion, invalidate]);
    useFrame(() => {
        frames.current++;
        const now = performance.now();
        const moving =
            rig.current?.step((now - previousTime.current) / 1000) ?? false;
        previousTime.current = now;
        if (rig.current?.key.shadow.needsUpdate) requestShadowUpdate(gl);
        recordCameraDiagnostic(gl.domElement, 'theme', theme);
        recordCameraDiagnostic(gl.domElement, 'themeSettled', String(!moving));
        // gl.info refleja el render anterior: un segundo fotograma permite medir el GLB ya compilado.
        recordCameraDiagnostic(
            gl.domElement,
            'performanceReady',
            String(frames.current > 1),
        );
        if (!moving && import.meta.env.DEV)
            recordCameraDiagnostic(
                gl.domElement,
                'performance',
                JSON.stringify({
                    calls: gl.info.render.calls,
                    triangles: gl.info.render.triangles,
                    programs: gl.info.programs?.length,
                    textures: gl.info.memory.textures,
                    geometries: gl.info.memory.geometries,
                    exposure: gl.toneMappingExposure,
                    bloom: false,
                    localLights: rig.current?.locals.length ?? 0,
                }),
            );
        if (moving || frames.current === 1) invalidate();
    }, -3);
    // Después del controlador existente de cámara; no depende de su posición del fotograma anterior.
    useFrame(() => {
        if (
            campus.bundle.manifest.assetId !== 'arxnet.scene.company-world' ||
            campus.bundle.manifest.assetVersion !== '0.2.0' ||
            !rig.current
        )
            return;
        const base = rig.current.fogRange;
        const range = architectureFogRange(
            campus.overviewPoints,
            camera,
            base.near,
            base.far,
        );
        rig.current.fog.near = range.near;
        rig.current.fog.far = range.far;
        if (import.meta.env.DEV)
            recordCameraDiagnostic(
                gl.domElement,
                'fogOffset',
                String(range.offset),
            );
    }, -0.5);
    return null;
}
