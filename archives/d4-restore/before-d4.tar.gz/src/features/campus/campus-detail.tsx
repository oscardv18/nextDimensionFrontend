import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import type { Campus } from './asset';
import { DetailController } from './detail-controller';
import type { DetailNavigation } from './detail-controller';
import { campusGraphics } from './graphics-quality';
import { requestShadowUpdate } from './shadow-cache';
import { recordCameraDiagnostic } from './camera-diagnostics';

export function CampusDetail({
    campus,
    navigation,
}: {
    campus: Campus;
    navigation: () => DetailNavigation;
}) {
    const { camera, gl, invalidate } = useThree();
    const controller = useRef<DetailController | null>(null);
    useEffect(() => {
        const detail = new DetailController(campus, campusGraphics.name);
        controller.current = detail;
        invalidate();
        return () => {
            detail.dispose();
            controller.current = null;
            requestShadowUpdate(gl);
        };
    }, [campus, gl, invalidate]);
    useFrame(() => {
        const detail = controller.current;
        if (!detail) return;
        const changed = detail.update(
            camera.position,
            navigation(),
            performance.now(),
        );
        if (changed) {
            requestShadowUpdate(gl);
            invalidate();
        }
        if (import.meta.env.DEV && (changed || !gl.domElement.dataset.detail))
            recordCameraDiagnostic(
                gl.domElement,
                'detail',
                JSON.stringify(detail.snapshot()),
            );
    }, -1);
    return null;
}
