/// <reference types="node" />
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import {
    Box3,
    Mesh,
    PerspectiveCamera,
    Raycaster,
    Scene,
    Vector3,
} from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import {
    activeAsset,
    companyWorldBundle,
    selectAsset,
    worldFov,
} from './asset-bundle';
import { disposeCampus, prepareCampus, resolveCampus } from './asset';
import { CampusTheme, validateThemeManifest } from './campus-theme';
import { applyRevealLayers, validateRevealLayers } from './reveal-layers';
import {
    boxCorners,
    cameraPose,
    panelInsets,
    safeArea,
} from './camera-framing';
import { navigationLimits, constrainManualPose } from './manual-navigation';

async function load() {
    const file = readFileSync(
        'public/assets/arxnet.scene.company-world/0.1.0/asset.glb',
    );
    const bytes = new ArrayBuffer(file.byteLength);
    new Uint8Array(bytes).set(file);
    const campus = resolveCampus(
        (await new GLTFLoader().parseAsync(bytes, '')).scene,
        companyWorldBundle,
    );
    prepareCampus(campus);
    return campus;
}

describe('company-world c1/B experimental', () => {
    it('conserva el predeterminado y no persiste ni activa el candidato en producción', () => {
        expect(activeAsset.manifest.assetId).toBe('arxnet.scene.campus-pilot');
        expect(selectAsset('?world=company-world&fov=15', false)).toBe(
            selectAsset('', false),
        );
        expect(selectAsset('?world=company-world', true)).toBe(
            companyWorldBundle,
        );
        expect(selectAsset('?world=unknown', true).manifest.assetVersion).toBe(
            '0.4.0',
        );
        expect(worldFov('?fov=15', selectAsset('', true))).toBe(45);
        expect(worldFov('?fov=15', companyWorldBundle)).toBe(15);
        expect(worldFov('?fov=99', companyWorldBundle)).toBe(20);
        expect(selectAsset('', true).manifest.assetId).toBe(
            'arxnet.scene.campus-pilot',
        );
    });
    it('verifica hash, jerarquía, materiales reales y anotaciones de capas', async () => {
        const file = readFileSync(
            'public/assets/arxnet.scene.company-world/0.1.0/asset.glb',
        );
        expect(createHash('sha256').update(file).digest('hex')).toBe(
            companyWorldBundle.build.metrics.sha256,
        );
        const campus = await load();
        expect(campus.nodes.size).toBe(199);
        expect(campus.departments).toHaveLength(6);
        expect(campus.overviewPoints).toHaveLength(56);
        expect(() => validateThemeManifest(companyWorldBundle)).not.toThrow();
        expect(() => validateRevealLayers(campus)).not.toThrow();
        for (const id of companyWorldBundle.manifest.defaultHiddenNodeIds!)
            expect(campus.nodes.get(id)!.visible).toBe(false);
        const full = new Box3().setFromObject(campus.scene);
        expect(full.getSize(new Vector3()).length()).toBeGreaterThan(
            campus.bounds.getSize(new Vector3()).length(),
        );
        const corrupted = {
            ...companyWorldBundle,
            manifest: {
                ...companyWorldBundle.manifest,
                nodes: companyWorldBundle.manifest.nodes.slice(1),
            },
        };
        expect(() => resolveCampus(campus.scene, corrupted)).toThrow(
            'Node inventory mismatch',
        );
        disposeCampus(campus);
    });
    it('selecciona seis proxies y mantiene el pabellón fuera del raycast', async () => {
        const campus = await load();
        for (const department of campus.departments) {
            expect(department.hit).toBeInstanceOf(Mesh);
            const center = new Box3()
                .setFromObject(department.hit)
                .getCenter(new Vector3());
            const ray = new Raycaster(
                center.clone().add(new Vector3(0, 100, 0)),
                new Vector3(0, -1, 0),
            );
            expect(ray.intersectObject(department.hit)).not.toHaveLength(0);
        }
        campus.nodes.get('site.entrance')!.traverse((node) => {
            if (node instanceof Mesh)
                expect(node.userData.arxnet_role).toBe('visual');
        });
        disposeCampus(campus);
    });
    it('abre/cierra las seis capas, restaura vecinos y no mueve edificios durante cambios rápidos', async () => {
        const campus = await load();
        const transforms = [...campus.nodes.values()].map((node) =>
            node.matrixWorld.toArray(),
        );
        const bounds = campus.departments.map((entry) => entry.bounds.clone());
        for (const quality of ['high', 'balanced', 'low'] as const) {
            for (const department of campus.departments) {
                applyRevealLayers(
                    campus,
                    department.departmentId,
                    true,
                    quality,
                );
                for (const other of campus.departments) {
                    const owner = other.hit.parent!.userData
                        .arxnet_node_id as keyof NonNullable<
                        typeof companyWorldBundle.manifest.revealLayers
                    >;
                    const layers =
                        companyWorldBundle.manifest.revealLayers![owner];
                    const selected = other === department;
                    expect(campus.nodes.get(layers.roof[0])!.visible).toBe(
                        !selected,
                    );
                    expect(
                        campus.nodes.get(layers.facadeFront[0])!.visible,
                    ).toBe(!selected);
                    expect(campus.nodes.get(layers.outline[0])!.visible).toBe(
                        selected,
                    );
                    if (selected)
                        expect(
                            campus.nodes.get(layers.interior[0])!.visible,
                        ).toBe(true);
                }
                applyRevealLayers(
                    campus,
                    department.departmentId,
                    false,
                    quality,
                );
                expect(
                    department.hit.parent!.children.find((n) =>
                        n.userData.arxnet_node_id.endsWith('.roof'),
                    )!.visible,
                ).toBe(true);
            }
            applyRevealLayers(campus, null, false, quality);
            for (const layers of Object.values(
                companyWorldBundle.manifest.revealLayers!,
            )) {
                expect(campus.nodes.get(layers.roof[0])!.visible).toBe(true);
                expect(campus.nodes.get(layers.facadeFront[0])!.visible).toBe(
                    true,
                );
                expect(campus.nodes.get(layers.outline[0])!.visible).toBe(
                    false,
                );
            }
        }
        campus.scene.updateMatrixWorld(true);
        expect(
            [...campus.nodes.values()].map((node) =>
                node.matrixWorld.toArray(),
            ),
        ).toEqual(transforms);
        expect(campus.departments.map((entry) => entry.bounds)).toEqual(bounds);
        disposeCampus(campus);
    });
    it('aplica oscuro/claro sin nuevas luces, materiales o texturas', async () => {
        const campus = await load();
        const rig = new CampusTheme(
            campus,
            new Scene(),
            { toneMappingExposure: 1 },
            'dark',
        );
        expect(rig.locals).toHaveLength(0);
        expect(rig.materials.size).toBe(17);
        const original = [...rig.materials.values()].flat().map((material) => ({
            uuid: material.uuid,
            version: material.version,
            map: material.map,
        }));
        rig.applyTheme('light', false);
        rig.step(0.16);
        rig.applyTheme('dark', false);
        rig.step(0.32);
        rig.applyTheme('light', true);
        expect(rig.background.getHexString()).toBe('eef0f3');
        expect(
            [...rig.materials.values()].flat().map((material) => ({
                uuid: material.uuid,
                version: material.version,
                map: material.map,
            })),
        ).toEqual(original);
        rig.dispose();
        disposeCampus(campus);
    });
    it('encuadra C20/C15 en escritorio y móvil sin depender de capas, conserva orientación y retorno', async () => {
        const campus = await load();
        const report: object[] = [];
        for (const fov of [20, 15])
            for (const viewport of [
                { width: 1440, height: 900 },
                { width: 1920, height: 1080 },
                { width: 390, height: 844 },
            ]) {
                const camera = new PerspectiveCamera(
                    fov,
                    viewport.width / viewport.height,
                    0.5,
                    10000,
                );
                const insets = {
                    top: 64,
                    left: viewport.width < 760 ? 0 : 70,
                    bottom: 90,
                    right: 0,
                };
                const initial = cameraPose(
                    campus,
                    null,
                    camera,
                    camera.aspect,
                    viewport,
                    insets,
                );
                for (const selected of [
                    null,
                    ...campus.departments.map((entry) => entry.departmentId),
                ]) {
                    const areaInsets = selected
                        ? panelInsets(viewport, true, insets)
                        : insets;
                    const pose = cameraPose(
                        campus,
                        selected,
                        camera,
                        camera.aspect,
                        viewport,
                        areaInsets,
                    );
                    camera.position.copy(pose.position);
                    camera.lookAt(pose.target);
                    camera.updateMatrixWorld(true);
                    const department = campus.departments.find(
                        (entry) => entry.departmentId === selected,
                    );
                    const points = department
                        ? boxCorners(department.bounds)
                        : campus.overviewPoints;
                    const projected = points.map((point) =>
                        point.clone().project(camera),
                    );
                    const area = safeArea(viewport, areaInsets, !department);
                    for (const p of projected) {
                        expect(p.x).toBeGreaterThanOrEqual(area.left - 0.0001);
                        expect(p.x).toBeLessThanOrEqual(area.right + 0.0001);
                        expect(p.y).toBeGreaterThanOrEqual(
                            area.bottom - 0.0001,
                        );
                        expect(p.y).toBeLessThanOrEqual(area.top + 0.0001);
                        expect(p.z).toBeLessThan(1);
                        expect(p.z).toBeGreaterThan(-1);
                    }
                    report.push({
                        fov,
                        viewport,
                        selected: selected ?? 'overview',
                        distance: pose.position.distanceTo(pose.target),
                        screenBounds: {
                            left: Math.min(...projected.map((p) => p.x)),
                            right: Math.max(...projected.map((p) => p.x)),
                            top: Math.max(...projected.map((p) => p.y)),
                            bottom: Math.min(...projected.map((p) => p.y)),
                        },
                    });
                    applyRevealLayers(campus, selected, true, 'high');
                    const after = cameraPose(
                        campus,
                        selected,
                        camera,
                        camera.aspect,
                        viewport,
                        areaInsets,
                    );
                    expect(after.position.equals(pose.position)).toBe(true);
                }
                applyRevealLayers(campus, null, false, 'high');
                expect(
                    cameraPose(
                        campus,
                        null,
                        camera,
                        camera.aspect,
                        viewport,
                        insets,
                    ).position.equals(initial.position),
                ).toBe(true);
                const limits = navigationLimits(campus.bounds);
                limits.maxDistance = Math.max(
                    limits.maxDistance,
                    initial.position.distanceTo(initial.target) * 1.6,
                );
                const manual = {
                    position: initial.position.clone(),
                    target: initial.target.clone(),
                };
                constrainManualPose(manual, limits, camera.near);
                expect(
                    manual.position.distanceTo(initial.position),
                ).toBeLessThan(0.0001);
            }
        if (process.env.CAMPUS_WRITE_COMPARISON === '1')
            writeFileSync(
                'docs/campus/company-world-framing-c2.json',
                JSON.stringify(
                    {
                        kind: 'Analytical projections; not browser screenshots',
                        results: report,
                    },
                    null,
                    2,
                ) + '\n',
            );
        disposeCampus(campus);
    });
});
