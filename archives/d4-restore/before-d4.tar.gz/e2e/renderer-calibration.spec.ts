import { expect, test } from '@playwright/test';
import type { Page, TestInfo } from '@playwright/test';

const experiments = {
    absolute: 'glassEnvironment=absolute',
    relative: 'glassEnvironment=relative',
    ambient: 'lighting=ambient-half',
    environment: 'lighting=environment-half',
    key: 'lighting=key-half',
    fill: 'lighting=fill-off',
    architecture: 'reflectionEnvironment=architecture',
} as const;

async function capture(
    page: Page,
    info: TestInfo,
    query: string,
    theme: string,
    view: string,
    name: string,
) {
    const quality = process.env.CALIBRATION_QUALITY ?? 'high';
    expect(['high', 'balanced', 'low']).toContain(quality);
    await page.goto(
        `/campus-3d?assetVersion=0.4.0&quality=${quality}&calibration=on&${query}`,
    );
    const viewport = page.getByTestId('campus-viewport');
    const canvas = viewport.locator('canvas');
    await expect(viewport).toHaveAttribute('data-camera', 'overview', {
        timeout: 20000,
    });
    if (view === 'compras') {
        const search = page.getByRole('combobox');
        await search.fill('Compras');
        await search.press('Enter');
        await expect(viewport).toHaveAttribute(
            'data-camera',
            'shared.procurement',
        );
    }
    await expect(canvas).toHaveAttribute('data-theme', theme);
    await expect(canvas).toHaveAttribute('data-theme-settled', 'true');
    await expect(canvas).toHaveAttribute('data-labels-settled', 'true');
    await expect(canvas).toHaveAttribute('data-glass-environment', /\S/);
    await expect
        .poll(() =>
            page.evaluate(
                () =>
                    document
                        .getAnimations()
                        .filter(
                            (a) =>
                                a.playState === 'running' &&
                                a.effect?.getComputedTiming().iterations !==
                                    Infinity,
                        ).length,
            ),
        )
        .toBe(0);
    await page.evaluate(() =>
        window.dispatchEvent(new Event('campus:benchmark')),
    );
    await expect(canvas).toHaveAttribute('data-benchmark-state', 'complete', {
        timeout: 10000,
    });
    const probe = JSON.parse(
        (await canvas.getAttribute('data-performance-probe'))!,
    );
    const glass = JSON.parse(
        (await canvas.getAttribute('data-glass-environment'))!,
    );
    const calibration = JSON.parse(
        (await canvas.getAttribute('data-renderer-calibration'))!,
    );
    const expected =
        calibration.glass === 'absolute'
            ? theme === 'dark'
                ? 1
                : 1.4
            : calibration.glass === 'relative'
              ? (theme === 'dark' ? 1 : 1.4) * glass.sceneIntensity
              : glass.sceneIntensity;
    expect(glass.measuredUniformIntensity).toBeCloseTo(expected, 5);
    expect(glass.explicitMap).toBe(calibration.glass !== 'reference');
    expect(probe.assetVersion).toBe('0.4.0');
    expect(probe.quality.name).toBe(quality);
    expect(probe.postprocessing.enabled).toBe(false);
    expect(probe.measured.frame.samples).toBeGreaterThan(0);
    const camera = await canvas.getAttribute('data-fit');
    const image = await page.screenshot({
        path: info.outputPath(`${name}.png`),
        animations: 'allow',
    });
    await info.attach(`${name}.json`, {
        body: JSON.stringify({ probe, glass, calibration, camera }, null, 2),
        contentType: 'application/json',
    });
    return { image, camera };
}

for (const theme of ['dark', 'light']) {
    for (const width of [1440, 1920])
        test(`Calibración: referencia real ${theme} ${width}`, async ({
            page,
        }, info) => {
            await page.setViewportSize({
                width,
                height: width === 1440 ? 900 : 1080,
            });
            await page.addInitScript(
                (theme) => localStorage.setItem('appearance', theme),
                theme,
            );
            await capture(page, info, '', theme, 'overview', 'reference');
        });
    for (const [experiment, query] of Object.entries(experiments))
        for (const view of ['overview', 'compras'])
            test(`Calibración: ${theme} ${view} ${experiment}`, async ({
                page,
            }, info) => {
                await page.setViewportSize({ width: 1440, height: 900 });
                await page.addInitScript(
                    (theme) => localStorage.setItem('appearance', theme),
                    theme,
                );
                const errors: string[] = [];
                page.on('pageerror', (error) => errors.push(error.message));
                const reference = await capture(
                    page,
                    info,
                    '',
                    theme,
                    view,
                    'reference',
                );
                const calibrated = await capture(
                    page,
                    info,
                    query,
                    theme,
                    view,
                    'experiment',
                );
                expect(calibrated.camera).toBe(reference.camera);
                expect(errors).toEqual([]);
                // Dos capturas de viewport completo, no dos canvas reducidos dentro del Shell.
                await info.attach('comparison.html', {
                    body: `<!doctype html><meta charset="utf-8"><title>${theme}/${view}/${experiment}</title><style>body{background:#17191e;color:white;font:16px sans-serif}main{display:flex;gap:12px}figure{margin:0;width:50%}img{width:100%}</style><h1>${theme}/${view}/${experiment}</h1><main><figure><figcaption>Referencia 0.4.0</figcaption><img src="data:image/png;base64,${reference.image.toString('base64')}"></figure><figure><figcaption>Experimento reversible</figcaption><img src="data:image/png;base64,${calibrated.image.toString('base64')}"></figure></main>`,
                    contentType: 'text/html',
                });
            });
}

test('Calibración: cambio de tema conserva canvas, programas y textura compartida', async ({
    page,
}, info) => {
    await page.addInitScript(() => localStorage.setItem('appearance', 'dark'));
    await capture(
        page,
        info,
        'glassEnvironment=relative',
        'dark',
        'compras',
        'dark',
    );
    const canvas = page.getByTestId('campus-viewport').locator('canvas');
    const handle = await canvas.elementHandle();
    const initial = JSON.parse(
        (await canvas.getAttribute('data-performance-probe'))!,
    ).measured;
    for (const [theme, name, intensity] of [
        ['light', 'Claro', 0.98],
        ['dark', 'Oscuro', 0.2],
    ] as const) {
        await page.getByRole('button', { name: 'Apariencia' }).click();
        await page.getByRole('menuitemradio', { name, exact: true }).click();
        await page.getByRole('button', { name: 'Apariencia' }).click();
        await expect(canvas).toHaveAttribute('data-theme', theme);
        await expect(canvas).toHaveAttribute('data-theme-settled', 'true');
        await expect
            .poll(
                async () =>
                    JSON.parse(
                        (await canvas.getAttribute('data-glass-environment'))!,
                    ).measuredUniformIntensity,
            )
            .toBeCloseTo(intensity, 5);
        await page.evaluate(() =>
            window.dispatchEvent(new Event('campus:benchmark')),
        );
        await expect(canvas).toHaveAttribute(
            'data-benchmark-state',
            'complete',
            { timeout: 10000 },
        );
        const current = JSON.parse(
            (await canvas.getAttribute('data-performance-probe'))!,
        ).measured;
        expect(current.programs).toBe(initial.programs);
        expect(current.textures).toBe(initial.textures);
        expect(
            await handle!.evaluate(
                (node) =>
                    node === document.querySelector('.campus-viewport canvas'),
            ),
        ).toBe(true);
    }
});
