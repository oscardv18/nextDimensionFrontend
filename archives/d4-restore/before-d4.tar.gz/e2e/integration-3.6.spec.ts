import { expect, test } from '@playwright/test';
import type { Page } from '@playwright/test';

async function shellReady(page: Page) {
    await expect
        .poll(() =>
            page.evaluate(
                () =>
                    document
                        .getAnimations()
                        .filter(
                            (animation) =>
                                animation.playState === 'running' &&
                                animation.effect?.getComputedTiming()
                                    .iterations !== Infinity,
                        ).length,
            ),
        )
        .toBe(0);
}

for (const quality of ['high', 'balanced', 'low'])
    for (const theme of ['dark', 'light'])
        for (const view of [
            'overview',
            'shared.procurement',
            'shared.warehouse',
        ]) {
            test(`Fase 3.6: ${quality}/${theme}/${view}`, async ({
                page,
            }, testInfo) => {
                await page.setViewportSize({ width: 1440, height: 900 });
                await page.addInitScript(
                    (appearance) =>
                        localStorage.setItem('appearance', appearance),
                    theme,
                );
                await page.goto(
                    `/campus-3d?assetVersion=0.4.0&quality=${quality}`,
                );
                const viewport = page.getByTestId('campus-viewport'),
                    canvas = viewport.locator('canvas');
                await expect(viewport).toHaveAttribute(
                    'data-camera',
                    'overview',
                    { timeout: 20000 },
                );
                if (view !== 'overview') {
                    const field = page.getByRole('combobox');
                    await field.fill(
                        view === 'shared.procurement' ? 'Compras' : 'Almacén',
                    );
                    await field.press('Enter');
                    await expect(viewport).toHaveAttribute(
                        'data-camera',
                        view,
                        { timeout: 10000 },
                    );
                }
                await expect(canvas).toHaveAttribute('data-theme', theme);
                await expect(canvas).toHaveAttribute(
                    'data-theme-settled',
                    'true',
                );
                await expect(canvas).toHaveAttribute(
                    'data-labels-settled',
                    'true',
                );
                await expect
                    .poll(() => canvas.getAttribute('data-detail'))
                    .not.toBeNull();
                const detail = JSON.parse(
                    (await canvas.getAttribute('data-detail'))!,
                );
                expect(detail.quality).toBe(quality);
                expect(detail.groups).toHaveLength(3);
                if (view !== 'overview') {
                    const group = detail.groups.find(
                        (g: { owner: string }) => g.owner === view,
                    );
                    expect(group.secondaryVisible).toBe(true);
                    expect(group.preservedMeshes).toBeGreaterThan(0);
                }
                await shellReady(page);
                await page.screenshot({
                    path: testInfo.outputPath('scene.png'),
                    animations: 'allow',
                });
                if (view === 'shared.procurement') {
                    await page
                        .getByRole('button', { name: 'Ver interior' })
                        .click();
                    await expect(canvas).toHaveAttribute(
                        'data-roof-visible',
                        'false',
                    );
                    await expect(canvas).toHaveAttribute(
                        'data-labels-settled',
                        'true',
                    );
                    await page.screenshot({
                        path: testInfo.outputPath('interior.png'),
                    });
                    const point = await page.evaluate(() => {
                        for (const y of [0.4, 0.5, 0.6, 0.7])
                            for (const x of [0.4, 0.5, 0.6]) {
                                const px = x * innerWidth,
                                    py = y * innerHeight;
                                if (
                                    document.elementFromPoint(px, py)
                                        ?.tagName === 'CANVAS'
                                )
                                    return { x: px, y: py };
                            }
                        throw new Error('No canvas point');
                    });
                    await page.mouse.move(point.x, point.y);
                    await page.mouse.down();
                    await page.mouse.move(point.x + 40, point.y + 10, {
                        steps: 6,
                    });
                    await page.mouse.up();
                    await page.mouse.wheel(0, -120);
                    await expect(viewport).toHaveAttribute(
                        'data-navigation',
                        'manual',
                    );
                    await expect(canvas).toHaveAttribute(
                        'data-manual-settled',
                        'true',
                    );
                    await page.screenshot({
                        path: testInfo.outputPath('manual-close.png'),
                    });
                    await page
                        .getByRole('button', { name: 'Ver interior' })
                        .click();
                    await expect(canvas).toHaveAttribute(
                        'data-roof-visible',
                        'true',
                    );
                }
            });
        }

// Mismo consumidor e instrumentación para comparar activos, sin sustituir archivos entre ejecuciones.
for (const version of ['0.3.0', '0.4.0'])
    for (const theme of ['dark', 'light'])
        test(`Fase 3.6: comparación ${version}/${theme}`, async ({
            page,
        }, testInfo) => {
            await page.setViewportSize({ width: 1440, height: 900 });
            await page.addInitScript(
                (appearance) => localStorage.setItem('appearance', appearance),
                theme,
            );
            await page.goto(`/campus-3d?assetVersion=${version}&quality=high`);
            const viewport = page.getByTestId('campus-viewport'),
                canvas = viewport.locator('canvas');
            await expect(viewport).toHaveAttribute('data-camera', 'overview', {
                timeout: 20000,
            });
            await page.evaluate(() =>
                window.dispatchEvent(new Event('campus:benchmark')),
            );
            await expect(canvas).toHaveAttribute(
                'data-benchmark-state',
                'complete',
                { timeout: 10000 },
            );
            const report = JSON.parse(
                (await canvas.getAttribute('data-performance-probe'))!,
            );
            expect(report.assetVersion).toBe(version);
            expect(report.measured.frame.samples).toBeGreaterThan(0);
            await testInfo.attach('performance.json', {
                body: JSON.stringify(report, null, 2),
                contentType: 'application/json',
            });
        });
