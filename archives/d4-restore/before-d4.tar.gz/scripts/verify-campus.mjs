// Verifica la copia local sin depender de Blender, WebGL ni paquetes 3D.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root = new URL('../', import.meta.url);
const readJson = (path) =>
    JSON.parse(readFileSync(new URL(path, root), 'utf8'));
const manifest = readJson('src/features/campus/assets/manifest.json');
const build = readJson('src/features/campus/assets/build.json');
const bytes = readFileSync(
    new URL(
        `public/assets/${manifest.assetId}/${manifest.assetVersion}/asset.glb`,
        root,
    ),
);
assert.equal(manifest.assetId, 'arxnet.scene.campus-pilot');
assert.equal(manifest.assetVersion, '0.4.0');
assert.equal(manifest.contractVersion, '1.0.0');
assert.equal(build.assetId, manifest.assetId);
assert.equal(build.assetVersion, manifest.assetVersion);
assert.equal(bytes.length, build.metrics.bytes);
assert.equal(
    createHash('sha256').update(bytes).digest('hex'),
    build.metrics.sha256,
);
assert.equal(bytes.readUInt32LE(0), 0x46546c67);
assert.equal(bytes.readUInt32LE(4), 2);
assert.equal(bytes.readUInt32LE(8), bytes.length);
assert.equal(bytes.readUInt32LE(16), 0x4e4f534a);
const gltf = JSON.parse(
    bytes.subarray(20, 20 + bytes.readUInt32LE(12)).toString(),
);
const nodes = new Map(
    gltf.nodes.map((node, index) => [
        node.extras.arxnet_node_id,
        { ...node, index },
    ]),
);
assert.equal(nodes.size, manifest.nodes.length);
for (const entry of manifest.nodes) {
    const node = nodes.get(entry.id);
    assert.ok(node, entry.id);
    assert.equal(node.name, entry.name);
    assert.equal(node.extras.arxnet_role, entry.role);
    if (entry.parent)
        assert.ok(nodes.get(entry.parent).children.includes(node.index));
    else assert.ok(gltf.scenes[0].nodes.includes(node.index));
    if (['hit', 'visual'].includes(entry.role))
        assert.equal(typeof node.mesh, 'number');
}
assert.equal(nodes.get('root').extras.arxnet_asset_id, manifest.assetId);
assert.equal(
    nodes.get('root').extras.arxnet_contract_version,
    manifest.contractVersion,
);
assert.equal(manifest.interactions.length, 6);
for (const entry of manifest.interactions) {
    for (const [key, role] of [
        ['hitNodeId', 'hit'],
        ['focusNodeId', 'focus'],
        ['labelNodeId', 'label'],
    ]) {
        assert.equal(nodes.get(entry[key]).extras.arxnet_role, role);
    }
    assert.ok(manifest.departmentIds.includes(entry.departmentId));
}
assert.ok(nodes.get('procurement.roof'));
const previous = readJson('src/features/campus/assets/0.2.0/manifest.json');
const previousBuild = readJson('src/features/campus/assets/0.2.0/build.json');
const previousBytes = readFileSync(
    new URL('public/assets/arxnet.scene.campus-pilot/0.2.0/asset.glb', root),
);
assert.equal(previousBytes.length, previousBuild.metrics.bytes);
assert.equal(
    createHash('sha256').update(previousBytes).digest('hex'),
    previousBuild.metrics.sha256,
);
assert.equal(previous.nodes.length, 94);
for (const entry of previous.nodes)
    assert.deepEqual(
        manifest.nodes.find((node) => node.id === entry.id),
        entry,
    );
assert.deepEqual(manifest.interactions, previous.interactions);
assert.deepEqual(manifest.departmentIds, previous.departmentIds);
const rollbackManifest = readJson(
    'src/features/campus/assets/0.3.0/manifest.json',
);
const rollbackBuild = readJson('src/features/campus/assets/0.3.0/build.json');
const rollbackThemes = readJson('src/features/campus/assets/0.3.0/themes.json');
const rollbackBytes = readFileSync(
    new URL('public/assets/arxnet.scene.campus-pilot/0.3.0/asset.glb', root),
);
assert.equal(rollbackManifest.nodes.length, 99);
assert.equal(rollbackBytes.length, rollbackBuild.metrics.bytes);
assert.equal(
    createHash('sha256').update(rollbackBytes).digest('hex'),
    rollbackBuild.metrics.sha256,
);
for (const document of [rollbackManifest, rollbackBuild, rollbackThemes]) {
    assert.equal(document.assetId, manifest.assetId);
    assert.equal(document.assetVersion, '0.3.0');
}
for (const entry of rollbackManifest.nodes)
    assert.deepEqual(
        manifest.nodes.find((node) => node.id === entry.id),
        entry,
    );
assert.deepEqual(manifest.interactions, rollbackManifest.interactions);
assert.deepEqual(manifest.departmentIds, rollbackManifest.departmentIds);
assert.deepEqual(
    rollbackThemes.environmentNodeIds,
    rollbackManifest.environmentNodeIds,
);
for (const id of manifest.detailNodeIds) {
    assert.equal(nodes.get(id).extras.arxnet_role, 'group');
    const children = [...nodes.values()].filter((node) =>
        nodes.get(id).children.includes(node.index),
    );
    assert.ok(children.length > 0);
    for (const child of children) {
        assert.equal(child.extras.arxnet_role, 'visual');
        assert.ok(
            !rollbackManifest.nodes.some(
                (node) => node.id === child.extras.arxnet_node_id,
            ),
        );
    }
}
const provenance = readJson('docs/campus/provenance-0.4.0.json');
for (const entry of provenance.copiedFiles) {
    const copy = readFileSync(new URL(entry.file, root));
    assert.equal(copy.length, entry.bytes);
    assert.equal(createHash('sha256').update(copy).digest('hex'), entry.sha256);
}
for (const entry of readJson('docs/campus/provenance-0.3.0.json').copiedFiles) {
    const path = entry.file.replace(
        'src/features/campus/assets/',
        'src/features/campus/assets/0.3.0/',
    );
    const copy = readFileSync(new URL(path, root));
    assert.equal(copy.length, entry.bytes);
    assert.equal(createHash('sha256').update(copy).digest('hex'), entry.sha256);
}
const themes = readJson('src/features/campus/assets/themes.json');
assert.equal(themes.assetId, manifest.assetId);
assert.equal(themes.assetVersion, manifest.assetVersion);
assert.equal(themes.contractVersion, manifest.contractVersion);
assert.equal(themes.profileVersion, '1.0.0');
assert.deepEqual(themes.environmentNodeIds, manifest.environmentNodeIds);
assert.equal(gltf.materials.length, Object.keys(themes.materials).length);
assert.equal(gltf.images.length, Object.keys(themes.textures).length);
assert.equal((gltf.extensionsUsed ?? []).length, 0);
for (const material of gltf.materials) {
    const spec = themes.materials[material.name];
    assert.ok(spec, material.name);
    assert.ok(
        Math.abs(
            (material.pbrMetallicRoughness.roughnessFactor ?? 1) -
                spec.roughness,
        ) < 1e-6,
    );
    assert.ok(
        Math.abs(
            (material.pbrMetallicRoughness.metallicFactor ?? 1) -
                spec.metalness,
        ) < 1e-6,
    );
    if (material.alphaMode === 'BLEND') {
        assert.equal(material.doubleSided ?? false, false);
        assert.ok(
            Math.abs(
                material.pbrMetallicRoughness.baseColorFactor[3] -
                    themes.themes.dark.materials[material.name].opacity,
            ) < 1e-6,
        );
    }
}
for (const image of gltf.images) {
    assert.equal(image.mimeType, 'image/png');
    assert.equal(typeof image.bufferView, 'number');
    const view = gltf.bufferViews[image.bufferView];
    const binOffset = 20 + bytes.readUInt32LE(12) + 8;
    const png = bytes.subarray(
        binOffset + (view.byteOffset ?? 0),
        binOffset + (view.byteOffset ?? 0) + view.byteLength,
    );
    assert.equal(png.subarray(1, 4).toString(), 'PNG');
    assert.equal(png.readUInt32BE(16), 512);
    assert.equal(png.readUInt32BE(20), 512);
}
for (const [name, theme] of Object.entries(themes.themes)) {
    assert.deepEqual(
        Object.keys(theme.materials).sort(),
        Object.keys(themes.themes.dark.materials).sort(),
    );
    for (const [id, patch] of Object.entries(theme.materials)) {
        for (const key of Object.keys(patch))
            assert.ok(
                themes.materials[id].themeKeys.includes(key),
                `${name}:${id}:${key}`,
            );
        assert.deepEqual(
            Object.keys(patch).sort(),
            Object.keys(themes.themes.dark.materials[id]).sort(),
        );
    }
    assert.equal(
        theme.lights.key.castShadow,
        themes.themes.dark.lights.key.castShadow,
    );
    assert.equal(theme.lights.fill.castShadow, false);
}
for (const light of themes.localLights) {
    assert.ok(nodes.has(light.parentNodeId));
    assert.equal(light.castShadow, false);
}
assert.equal(themes.localLights.length, 14);
for (const id of manifest.environmentNodeIds) assert.ok(nodes.has(id));
process.stdout.write(
    `Campus ${manifest.assetVersion}: SHA-256, ${nodes.size} nodos, 99 identidades anteriores compatibles, ${gltf.materials.length} materiales, ${gltf.images.length} PNG y detalles verificados; versiones 0.3.0 y 0.2.0 íntegras.\n`,
);

// El candidato se verifica aparte; nunca sustituye las comprobaciones del activo predeterminado.
const worldProvenance = readJson(
    'docs/campus/provenance-company-world-c1.json',
);
for (const entry of worldProvenance.files) {
    const copy = readFileSync(new URL(entry.copy, root));
    assert.equal(copy.length, entry.bytes);
    assert.equal(createHash('sha256').update(copy).digest('hex'), entry.sha256);
}
const worldPath = 'src/features/campus/assets/company-world/0.1.0/';
const worldManifest = readJson(worldPath + 'manifest.json');
const worldBuild = readJson(worldPath + 'build.json');
const worldThemes = readJson(worldPath + 'themes.json');
assert.equal(worldManifest.assetId, 'arxnet.scene.company-world');
assert.equal(worldManifest.assetVersion, '0.1.0');
assert.equal(worldManifest.candidate.variant, 'b');
assert.equal(worldManifest.candidate.published, false);
for (const metadata of [worldBuild, worldThemes]) {
    assert.equal(metadata.assetId, worldManifest.assetId);
    assert.equal(metadata.assetVersion, worldManifest.assetVersion);
}
assert.equal(worldThemes.profileVersion, '1.0.0');
const worldBytes = readFileSync(
    new URL('public/assets/arxnet.scene.company-world/0.1.0/asset.glb', root),
);
assert.equal(worldBytes.length, worldBuild.metrics.bytes);
assert.equal(
    createHash('sha256').update(worldBytes).digest('hex'),
    worldBuild.metrics.sha256,
);
assert.equal(worldBytes.readUInt32LE(0), 0x46546c67);
assert.equal(worldBytes.readUInt32LE(4), 2);
assert.equal(worldBytes.readUInt32LE(8), worldBytes.length);
const worldGltf = JSON.parse(
    worldBytes.subarray(20, 20 + worldBytes.readUInt32LE(12)).toString(),
);
const worldNodes = new Map(
    worldGltf.nodes.map((node, index) => [
        node.extras.arxnet_node_id,
        { ...node, index },
    ]),
);
assert.equal(worldNodes.size, worldManifest.nodes.length);
for (const entry of worldManifest.nodes) {
    const node = worldNodes.get(entry.id);
    assert.ok(node, entry.id);
    assert.equal(node.name, entry.name);
    assert.equal(node.extras.arxnet_role, entry.role);
    if (entry.parent)
        assert.ok(worldNodes.get(entry.parent).children.includes(node.index));
    else assert.ok(worldGltf.scenes[0].nodes.includes(node.index));
    if (['visual', 'hit'].includes(entry.role))
        assert.equal(worldGltf.meshes[node.mesh].primitives.length, 1);
}
assert.equal(
    worldNodes.get('root').extras.arxnet_asset_id,
    worldManifest.assetId,
);
assert.equal(
    worldNodes.get('root').extras.arxnet_contract_version,
    worldManifest.contractVersion,
);
assert.deepEqual(
    [...worldManifest.departmentIds].sort(),
    [...manifest.departmentIds].sort(),
);
for (const entry of worldManifest.interactions)
    for (const [field, role] of [
        ['hitNodeId', 'hit'],
        ['focusNodeId', 'focus'],
        ['labelNodeId', 'label'],
    ])
        assert.equal(worldNodes.get(entry[field]).extras.arxnet_role, role);
for (const id of [
    ...worldManifest.overviewFramingNodeIds,
    ...worldManifest.defaultHiddenNodeIds,
])
    assert.ok(worldNodes.has(id));
assert.equal(
    worldGltf.materials.length,
    Object.keys(worldThemes.materials).length,
);
console.log(
    'Company world c1/B 0.1.0: copias, SHA-256, 199 nodos, jerarquía y seis departamentos verificados; campus-pilot permanece predeterminado.',
);

// D.2 permanece independiente de C.1: comprobar las copias y las identidades anteriores.
const d2Provenance = readJson('docs/campus/provenance-company-world-d2.json');
for (const entry of d2Provenance.files) {
    const copy = readFileSync(new URL(entry.copy, root));
    assert.equal(copy.length, entry.bytes);
    assert.equal(createHash('sha256').update(copy).digest('hex'), entry.sha256);
}
const d2Path = 'src/features/campus/assets/company-world/0.2.0/';
const d2Manifest = readJson(d2Path + 'manifest.json');
const d2Build = readJson(d2Path + 'build.json');
const d2Themes = readJson(d2Path + 'themes.json');
assert.equal(d2Manifest.assetId, worldManifest.assetId);
assert.equal(d2Manifest.assetVersion, '0.2.0');
assert.equal(d2Manifest.contractVersion, worldManifest.contractVersion);
for (const metadata of [d2Build, d2Themes]) {
    assert.equal(metadata.assetId, d2Manifest.assetId);
    assert.equal(metadata.assetVersion, d2Manifest.assetVersion);
}
assert.equal(d2Themes.profileVersion, '1.0.0');
for (const entry of worldManifest.nodes)
    assert.deepEqual(
        d2Manifest.nodes.find((node) => node.id === entry.id),
        entry,
    );
for (const key of [
    'interactions',
    'revealLayers',
    'visibilityStates',
    'overviewFramingNodeIds',
    'defaultHiddenNodeIds',
    'signs',
    'landmarks',
    'environmentNodeIds',
])
    assert.deepEqual(d2Manifest[key], worldManifest[key]);
const d2Bytes = readFileSync(
    new URL('public/assets/arxnet.scene.company-world/0.2.0/asset.glb', root),
);
assert.equal(d2Bytes.length, d2Build.metrics.bytes);
assert.equal(
    createHash('sha256').update(d2Bytes).digest('hex'),
    d2Build.metrics.sha256,
);
assert.equal(d2Bytes.readUInt32LE(0), 0x46546c67);
assert.equal(d2Bytes.readUInt32LE(4), 2);
assert.equal(d2Bytes.readUInt32LE(8), d2Bytes.length);
const d2Gltf = JSON.parse(
    d2Bytes.subarray(20, 20 + d2Bytes.readUInt32LE(12)).toString(),
);
const d2Nodes = new Map(
    d2Gltf.nodes.map((node, index) => [
        node.extras.arxnet_node_id,
        { ...node, index },
    ]),
);
assert.equal(d2Nodes.size, d2Manifest.nodes.length);
for (const entry of d2Manifest.nodes) {
    const node = d2Nodes.get(entry.id);
    assert.ok(node, entry.id);
    assert.equal(node.name, entry.name);
    assert.equal(node.extras.arxnet_role, entry.role);
    if (entry.parent)
        assert.ok(d2Nodes.get(entry.parent).children.includes(node.index));
    else assert.ok(d2Gltf.scenes[0].nodes.includes(node.index));
    if (['hit', 'visual'].includes(entry.role))
        assert.equal(d2Gltf.meshes[node.mesh].primitives.length, 1);
}
assert.equal(d2Gltf.materials.length, 21);
assert.equal(d2Themes.localLights.length, 4);
assert.equal(d2Gltf.images?.length ?? 0, 0);
for (const ids of Object.values(d2Manifest.zoneAnchors))
    for (const id of ids)
        assert.equal(d2Nodes.get(id).extras.arxnet_role, 'label');
assert.deepEqual(
    readJson(d2Path + 'camera-candidates.json'),
    readJson(worldPath + 'camera-candidates.json'),
);
console.log(
    'Company world D.2 0.2.0: SHA-256, 246 nodos, 199 identidades C.1, 21 materiales, cuatro luces y nueve anclas verificados.',
);
